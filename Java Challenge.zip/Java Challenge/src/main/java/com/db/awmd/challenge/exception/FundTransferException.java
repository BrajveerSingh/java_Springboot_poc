package com.db.awmd.challenge.exception;

public class FundTransferException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = -2963368686833502204L;

	public FundTransferException(String msg) {
        super(msg);
    }
}
